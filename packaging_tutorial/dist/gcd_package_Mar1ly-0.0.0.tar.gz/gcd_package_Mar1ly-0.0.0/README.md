# GCD Package

This is a simple gcd package. To find the greatest common divisor of two number.